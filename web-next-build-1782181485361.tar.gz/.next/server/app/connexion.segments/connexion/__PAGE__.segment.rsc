1:"$Sreact.fragment"
2:I[7393,["5587","static/chunks/5587-933f3258279c6072.js","3357","static/chunks/3357-34f83f27e05c62b1.js","2247","static/chunks/2247-31f68647d1339fed.js","5106","static/chunks/app/connexion/page-cc95291ebf5e7868.js"],"AdminLoginForm"]
3:I[887,[],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"pm71z9B2K6-OFThUxlN4C"}
5:null
