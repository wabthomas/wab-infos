1:"$Sreact.fragment"
2:I[9630,[],""]
3:I[1380,[],""]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"pm71z9B2K6-OFThUxlN4C"}
