:HL["/_next/static/css/98d5ef01ab92c969.css","style"]
:HL["https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&family=Oswald:wght@500;600;700&family=Playfair+Display:wght@400;600;700&display=swap","style"]
:HL["/logo.png","image"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"contact","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"pm71z9B2K6-OFThUxlN4C"}
